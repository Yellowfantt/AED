def principal():
    print('MENU PRINCIPAL')
    print('1 - Acesso ADMIN')
    print('2 - Acesso CONTAS ')
    print('0 - SAIR')


def admin():
    print('MENU ADMIN')
    print('1 - Cadastrar')
    print('2 - Listar Todos')
    print('3 - buscar Conta')
    print('0 - SAIR')



def caixa_eletronico():
    print('CAIXA ELETRONICO')
    print('1 - SACAR')
    print('2 - DEPOSITAR')
    print('3 - TRANSFERIR')
    print('4 - SALDO')
    print('0 - SAIR')

